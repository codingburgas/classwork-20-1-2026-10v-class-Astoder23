#include <iostream>
#include "../Project1/math.h"

using namespace std;

int main() {
	int x;
	int y;
	cin >> x >> y;
	cout << add1(x, y) << "\n" << subtract(x, y) << "\n" << multiply(x, y) << "\n" << divide(x, y) << "\n";
}
