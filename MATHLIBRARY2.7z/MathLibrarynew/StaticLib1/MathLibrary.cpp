?
#include "pch.h"
#include "framework.h"


#include <iostream>
#include"../MathLibrary/MathLibrary.h"

using namespace std;

double perimeter(double a, double b, double c)
{
    return a + b + c;
}
double plot(double a, double b) {
    return (a * b) / 2;
}