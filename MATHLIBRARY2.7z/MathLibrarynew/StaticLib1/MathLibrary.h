#pragma once

double perimeter(double a, double b, double c);
double plot(double a, double b);